/**
 * Created by sms ahmed on 23-08-16.
 */
import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App.jsx';

ReactDOM.render(
    <App/>,
    document.getElementById('app')
);

